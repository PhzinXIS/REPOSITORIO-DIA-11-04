/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package projetinhoale2.dia.pkg1104;

import javax.swing.JOptionPane;

/**
 *
 * @author paulo.hsferreira8
 */
public class PROJETINHOALE2DIA1104 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //JOptionPane.showMessageDialog(null,"CoMo VoCe EsTa");
        //JOptionPane.showMessageDialog(null,"Talvez");
       //OptionPane.showInputDialog(null,"Kindle");
        JOptionPane.showInputDialog(null,"Qual o seu nome?");
        JOptionPane.showConfirmDialog(null,"Você tem mais de 18 anos?");
    }
    
}
